# -*- coding: utf-8 -*-

"""
GameChanger TV - Kodi video addon skeleton

Kodi Nexus/Omega / Python 3

This example intentionally does NOT implement automated authentication
or bypass GameChanger access controls. Put your own authorized stream
handling code in the marked sections.
"""

import sys
from urllib.parse import parse_qsl

import xbmc
import xbmcgui
import xbmcplugin


# Kodi supplies these when it launches a plugin:// URL.
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]


# ----------------------------------------------------------------------
# Configuration
# ----------------------------------------------------------------------

# For testing only:
# Replace this with an HLS URL that you are authorized to play.
#
# Example:
# https://example.com/path/stream.m3u8
TEST_STREAM_URL = "https://example.com/your-authorized-stream.m3u8"


# ----------------------------------------------------------------------
# Authentication placeholder
# ----------------------------------------------------------------------

def authenticate():
    """
    Placeholder for authentication.

    If GameChanger provides an officially supported authentication
    mechanism that you are authorized to use, implement it here.

    Do NOT hard-code real passwords or session credentials into the
    addon source. Prefer Kodi settings or another secure mechanism.

    Example of the intended flow:

        username = "..."
        password = "..."

        # Perform your authorized login here.
        # Return a session/token object if necessary.

    Returns:
        object/None
    """

    # TODO:
    # Add your authorized authentication/session setup here.

    return None


# ----------------------------------------------------------------------
# Stream URL handling
# ----------------------------------------------------------------------

def play_stream(stream_url):
    """
    Give an authorized HLS stream to Kodi's video player.

    stream_url should normally be an HLS .m3u8 URL or another URL
    Kodi's player can handle.
    """

    if not stream_url:
        xbmcgui.Dialog().notification(
            "GameChanger TV",
            "No stream URL supplied.",
            xbmcgui.NOTIFICATION_ERROR
        )
        return

    # Create the playable ListItem.
    item = xbmcgui.ListItem(path=stream_url)

    # Tell Kodi that this URL is the resolved playable media.
    xbmcplugin.setResolvedUrl(
        HANDLE,
        True,
        item
    )


# ----------------------------------------------------------------------
# Kodi directory helpers
# ----------------------------------------------------------------------

def add_directory_item(label, url, is_folder=False):
    """
    Add an item to the Kodi directory.
    """

    item = xbmcgui.ListItem(label=label)

    xbmcplugin.addDirectoryItem(
        handle=HANDLE,
        url=url,
        listitem=item,
        isFolder=is_folder
    )


def show_main_menu():
    """
    Display the addon's main menu.
    """

    add_directory_item(
        "Live Games",
        BASE_URL + "?action=live",
        is_folder=True
    )

    add_directory_item(
        "Past Streams",
        BASE_URL + "?action=past",
        is_folder=True
    )

    xbmcplugin.endOfDirectory(HANDLE)


# ----------------------------------------------------------------------
# Example stream listings
# ----------------------------------------------------------------------

def show_live_games():
    """
    Example Live Games listing.

    Replace the placeholder stream URL with a stream obtained through
    your own authorized GameChanger integration/selection logic.
    """

    # TODO:
    # Put your authorized GameChanger stream selectors/parser here.
    #
    # For example, your own code might eventually produce:
    #
    # stream_url = find_authorized_stream(...)
    #
    # Do not put passwords, cookies, or private credentials directly
    # into this source file.

    stream_url = TEST_STREAM_URL

    item = xbmcgui.ListItem(label="Example Live Game")

    xbmcplugin.addDirectoryItem(
        handle=HANDLE,
        url=BASE_URL + "?action=play&url=" + stream_url,
        listitem=item,
        isFolder=False
    )

    xbmcplugin.endOfDirectory(HANDLE)


def show_past_streams():
    """
    Example Past Streams listing.
    """

    # TODO:
    # Replace this example with your authorized stream-selection logic.
    stream_url = TEST_STREAM_URL

    item = xbmcgui.ListItem(label="Example Past Stream")

    xbmcplugin.addDirectoryItem(
        handle=HANDLE,
        url=BASE_URL + "?action=play&url=" + stream_url,
        listitem=item,
        isFolder=False
    )

    xbmcplugin.endOfDirectory(HANDLE)


# ----------------------------------------------------------------------
# Main router
# ----------------------------------------------------------------------

def main():
    """
    Route Kodi's plugin:// URL to the appropriate function.
    """

    # Parse query parameters supplied by Kodi.
    query = dict(parse_qsl(sys.argv[2][1:]))

    action = query.get("action")

    if not action:
        show_main_menu()

    elif action == "live":
        show_live_games()

    elif action == "past":
        show_past_streams()

    elif action == "play":
        # In a production addon, validate this URL and ensure it came
        # from your authorized stream-selection code.
        stream_url = query.get("url")

        if stream_url:
            play_stream(stream_url)
        else:
            xbmcgui.Dialog().ok(
                "GameChanger TV",
                "No stream URL was supplied."
            )

    else:
        xbmcgui.Dialog().ok(
            "GameChanger TV",
            "Unknown action: " + str(action)
        )


if __name__ == "__main__":
    main()
